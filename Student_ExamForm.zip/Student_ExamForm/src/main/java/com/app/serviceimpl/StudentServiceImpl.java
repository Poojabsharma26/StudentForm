package com.app.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Student;
import com.app.repository.StudentRepository;
import com.app.service.StudentService;
 
@Service
public abstract class StudentServiceImpl  implements  StudentService{
  @Autowired
	private StudentRepository studentRepository;
	
	
	//public StudentServiceImpl(StudentRepository studentRepository) {
		//super();
		//this.studentRepository = studentRepository;
	//}

   //return list of students
	@Override
	public List<Student>getAllStudents(){
		return studentRepository.findAll();
	}
	
	public Student getStudent(Long Id) {
		return studentRepository.findById(Id).get();
	}
		public Student updateStudent(Student student) {
			return studentRepository.save(student); 
	}
	}


