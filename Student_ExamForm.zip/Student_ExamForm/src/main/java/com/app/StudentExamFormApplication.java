package com.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.app.entity.Student;
import com.app.repository.StudentRepository;
@SpringBootApplication(scanBasePackages={"student_API.student.services"})
public class StudentExamFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentExamFormApplication.class, args);
	}
	@Autowired
  private StudentRepository studentRepository;
	
	
	public void run(String... args)throws Exception{
		
	Student  student1=new Student(101,"Ram","Sharma","ramsharma@gmail.com",3500);
		studentRepository.save(student1);
		
		Student student2=new Student(102,"Sham","Varma","shamvarma@gmail.com",3500);
		studentRepository.save(student2);
		
		Student student3=new Student(103,"Karn","Sharma","karnsharma@gmail.com",3500);
		studentRepository.save(student3);

		Student student4=new Student(104,"Balram","Varma","balramvarma@gmail.com",3500);
		studentRepository.save(student4);



		
		
	}
}
